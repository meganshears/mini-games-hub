document.addEventListener("DOMContentLoaded", function () {
  let board = [];
  const boardSize = 8;
  const colors = ['red', 'blue', 'green', 'yellow', 'purple', 'orange'];
  let selectedGem = null;
  let score = 0;
  const targetScore = 100; // The target score to win
  let gameOver = false;

  function createBoard() {
    board = [];
    const gridContainer = document.getElementById('grid');
    gridContainer.innerHTML = ''; // Clear the grid before creating a new board
    score = 0;
    gameOver = false;

    // Fill the board with random gems
    for (let row = 0; row < boardSize; row++) {
      const rowArr = [];
      for (let col = 0; col < boardSize; col++) {
        const gem = document.createElement('div');
        gem.style.backgroundColor = getRandomColor();
        gem.dataset.row = row;
        gem.dataset.col = col;
        gem.classList.add('gem');
        gem.addEventListener('click', () => handleGemClick(gem, row, col));
        gridContainer.appendChild(gem);
        rowArr.push(gem);
      }
      board.push(rowArr);
    }

    // After creating the board, check for matches
    while (checkForMatches()) {
      shuffleBoard();
    }

    updateScoreDisplay(); // Update the score after creating the board
  }

  function getRandomColor() {
    return colors[Math.floor(Math.random() * colors.length)];
  }

  function checkForMatches() {
    let matchedGems = [];

    // Check horizontal matches
    for (let row = 0; row < boardSize; row++) {
      for (let col = 0; col < boardSize - 2; col++) {
        const currentGem = board[row][col];
        const nextGem = board[row][col + 1];
        const nextNextGem = board[row][col + 2];

        if (currentGem.style.backgroundColor === nextGem.style.backgroundColor &&
          currentGem.style.backgroundColor === nextNextGem.style.backgroundColor) {
          matchedGems.push(currentGem, nextGem, nextNextGem);
        }
      }
    }

    // Check vertical matches
    for (let col = 0; col < boardSize; col++) {
      for (let row = 0; row < boardSize - 2; row++) {
        const currentGem = board[row][col];
        const nextGem = board[row + 1][col];
        const nextNextGem = board[row + 2][col];

        if (currentGem.style.backgroundColor === nextGem.style.backgroundColor &&
          currentGem.style.backgroundColor === nextNextGem.style.backgroundColor) {
          matchedGems.push(currentGem, nextGem, nextNextGem);
        }
      }
    }

    return matchedGems.length > 0;
  }

  function shuffleBoard() {
    // Shuffle the board by randomly changing the color of the gems
    for (let row = 0; row < boardSize; row++) {
      for (let col = 0; col < boardSize; col++) {
        board[row][col].style.backgroundColor = getRandomColor();
      }
    }
  }

  function handleGemClick(gem, row, col) {
    if (gameOver) return; // Disable clicks after game over

    if (!selectedGem) {
      selectedGem = gem;
      gem.style.opacity = 0.7;
      gem.style.border = '2px solid #fff';
    } else {
      if (isAdjacent(selectedGem, gem)) {
        swapGems(selectedGem, gem);
        selectedGem.style.opacity = 1;
        selectedGem.style.border = '';
        selectedGem = null;
      } else {
        selectedGem.style.opacity = 1;
        selectedGem.style.border = '';
        selectedGem = gem;
        gem.style.opacity = 0.7;
        gem.style.border = '2px solid #fff';
      }
    }
  }

  function isAdjacent(gem1, gem2) {
    const row1 = parseInt(gem1.dataset.row);
    const col1 = parseInt(gem1.dataset.col);
    const row2 = parseInt(gem2.dataset.row);
    const col2 = parseInt(gem2.dataset.col);

    return (Math.abs(row1 - row2) === 1 && col1 === col2) || (Math.abs(col1 - col2) === 1 && row1 === row2);
  }

  function swapGems(gem1, gem2) {
    const tempColor = gem1.style.backgroundColor;
    gem1.style.backgroundColor = gem2.style.backgroundColor;
    gem2.style.backgroundColor = tempColor;
    checkMatches();
  }

  function checkMatches() {
    let matchedGems = [];

    // Horizontal and vertical matches (same as before)
    // ...

    if (matchedGems.length > 0) {
      score += matchedGems.length; // Increase score based on cleared gems
      removeMatchedGems(matchedGems);
    }

    if (score >= targetScore) {
      winGame();
    } else if (isGameOver()) {
      loseGame();
    }
  }

  function removeMatchedGems(matchedGems) {
    matchedGems.forEach(gem => gem.style.backgroundColor = '#eee');

    // Implement gravity (drop gems and refill the board)
    // ...
  }

  function isGameOver() {
    // Check if no valid moves can be made
    for (let row = 0; row < boardSize; row++) {
      for (let col = 0; col < boardSize; col++) {
        const gem = board[row][col];
        // Check if any valid swap is possible (you can define a helper function)
        if (canSwap(gem)) {
          return false; // If a valid swap exists, game is not over
        }
      }
    }
    return true; // No valid swaps left, game over
  }

  function canSwap(gem) {
    // Implement logic to check if a gem can swap with an adjacent one
    // For simplicity, return true or false based on the current gem's position
  }

  function winGame() {
    gameOver = true;
    alert("You win! You've reached the target score.");
  }

  function loseGame() {
    gameOver = true;
    alert("Game over! No valid moves left.");
  }

  function updateScoreDisplay() {
    const scoreElement = document.getElementById('score');
    if (scoreElement) {
      scoreElement.textContent = `Score: ${score}`;
    }
  }

  // Function to restart the game
  function restartGame() {
    createBoard();
    gameOver = false;
    score = 0;
    updateScoreDisplay();
  }

  // Function to start the game
  function startGame() {
    document.getElementById('menu').style.display = 'none';
    document.getElementById('game-container').style.display = 'block';
    createBoard();
  }

  // Attach event listeners for buttons
  document.getElementById('start-btn').addEventListener('click', startGame);
  document.getElementById('restart-btn').addEventListener('click', restartGame);
});

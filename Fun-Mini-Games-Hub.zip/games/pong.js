// Get DOM elements
const startBtn = document.getElementById("start-btn");
const instructionsBtn = document.getElementById("instructions-btn");
const backBtn = document.getElementById("back-btn");
const pausePlayBtn = document.getElementById("pause-play");
const restartBtn = document.getElementById("restart-btn");
const homeBtn = document.getElementById("home-btn");
const menu = document.getElementById("menu");
const instructions = document.getElementById("instructions");
const game = document.getElementById("game");
const score1 = document.getElementById("score-1");
const score2 = document.getElementById("score-2");
const timerDisplay = document.getElementById("timer");

let canvas = document.getElementById("pong");
let ctx = canvas.getContext("2d");

let paddleWidth = 10, paddleHeight = 100;
let ballRadius = 8;
let paddle1Y = canvas.height / 2 - paddleHeight / 2;
let paddle2Y = canvas.height / 2 - paddleHeight / 2;
let ballX = canvas.width / 2;
let ballY = canvas.height / 2;
let ballSpeedX = 5, ballSpeedY = 5;
let player1Score = 0, player2Score = 0;
let gamePaused = false;
let timer = 300; // 1 minute timer for testing
let interval;
let timerInterval;

// Function to start the game
function startGame() {
    menu.style.display = "none";
    instructions.style.display = "none";
    game.style.display = "block";
    interval = setInterval(updateGame, 1000 / 60);
    timerInterval = setInterval(updateTimer, 1000);
}

// Function to show instructions
function showInstructions() {
    menu.style.display = "none";
    instructions.style.display = "block";
}

// Function to go back to the menu
function goBackToMenu() {
    menu.style.display = "flex";
    instructions.style.display = "none";
    game.style.display = "none";
    clearInterval(interval);
    clearInterval(timerInterval);
    restartGame();
}

// Function to update game timer
function updateTimer() {
    if (timer > 0) {
        timer--;
        let minutes = Math.floor(timer / 60);
        let seconds = timer % 60;
        timerDisplay.textContent = `Time: ${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
    } else {
        endGame();
    }
}

// Function to restart the game
function restartGame() {
    player1Score = 0;
    player2Score = 0;
    ballX = canvas.width / 2;
    ballY = canvas.height / 2;
    ballSpeedX = 5;
    ballSpeedY = 5;
    paddle1Y = canvas.height / 2 - paddleHeight / 2;
    paddle2Y = canvas.height / 2 - paddleHeight / 2;
    score1.textContent = `Player 1: ${player1Score}`;
    score2.textContent = `Player 2: ${player2Score}`;
    timer = 300; // Reset timer to 1 minute
    updateTimer();
    gamePaused = false;
    clearInterval(interval);
    clearInterval(timerInterval);
    interval = setInterval(updateGame, 1000 / 60);
    timerInterval = setInterval(updateTimer, 1000);
}

// Function to toggle pause/play
function togglePausePlay() {
    if (gamePaused) {
        gamePaused = false;
        interval = setInterval(updateGame, 1000 / 60);
        timerInterval = setInterval(updateTimer, 1000);
        pausePlayBtn.textContent = "Pause";
    } else {
        gamePaused = true;
        clearInterval(interval);
        clearInterval(timerInterval);
        pausePlayBtn.textContent = "Play";
    }
}

// Function to update the game
function updateGame() {
    if (gamePaused) return;

    ballX += ballSpeedX;
    ballY += ballSpeedY;

    if (ballY + ballRadius >= canvas.height || ballY - ballRadius <= 0) {
        ballSpeedY = -ballSpeedY;
    }

    if (ballX + ballRadius >= canvas.width) {
        player1Score++;
        score1.textContent = `Player 1: ${player1Score}`;
        if (player1Score >= 10 || timer <= 0) {
            endGame();
        } else {
            resetBall();
        }
    }

    if (ballX - ballRadius <= 0) {
        player2Score++;
        score2.textContent = `Player 2: ${player2Score}`;
        if (player2Score >= 10 || timer <= 0) {
            endGame();
        } else {
            resetBall();
        }
    }

    if (ballX - ballRadius <= paddleWidth && ballY > paddle1Y && ballY < paddle1Y + paddleHeight) {
        ballSpeedX = -ballSpeedX;
    }

    if (ballX + ballRadius >= canvas.width - paddleWidth && ballY > paddle2Y && ballY < paddle2Y + paddleHeight) {
        ballSpeedX = -ballSpeedX;
    }

    draw();
}

// Function to reset the ball to the center
function resetBall() {
    ballX = canvas.width / 2;
    ballY = canvas.height / 2;
    ballSpeedX = -ballSpeedX;
}

// Function to end the game
function endGame() {
    clearInterval(interval);
    clearInterval(timerInterval);
    let winner = player1Score > player2Score ? "Player 1" : "Player 2";
    alert(`${winner} wins!`);
    restartGame();
}

// Function to draw the game on canvas
function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "white";
    ctx.fillRect(0, paddle1Y, paddleWidth, paddleHeight);
    ctx.fillRect(canvas.width - paddleWidth, paddle2Y, paddleWidth, paddleHeight);
    ctx.beginPath();
    ctx.arc(ballX, ballY, ballRadius, 0, Math.PI * 2);
    ctx.fill();
}

// Control functions for player paddles
document.addEventListener("keydown", function (e) {
    if (e.key === "w" && paddle1Y > 0) {
        paddle1Y -= 10;
    } else if (e.key === "s" && paddle1Y < canvas.height - paddleHeight) {
        paddle1Y += 10;
    } else if (e.key === "ArrowUp" && paddle2Y > 0) {
        paddle2Y -= 10;
    } else if (e.key === "ArrowDown" && paddle2Y < canvas.height - paddleHeight) {
        paddle2Y += 10;
    }
});

// Event listeners for buttons
startBtn.addEventListener("click", startGame);
instructionsBtn.addEventListener("click", showInstructions);
backBtn.addEventListener("click", goBackToMenu);
pausePlayBtn.addEventListener("click", togglePausePlay);
restartBtn.addEventListener("click", restartGame);
homeBtn.addEventListener("click", goBackToMenu);

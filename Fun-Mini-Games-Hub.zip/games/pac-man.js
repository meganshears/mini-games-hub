// Initialize Variables
const pacman = document.getElementById("pacman");
const maze = document.getElementById("maze");
const scoreDisplay = document.getElementById("score");
let score = 0;
let powerMode = false;
let powerTimer;
let collisionHandled = false; // Prevent repeated collision handling

// Maze Layout
const mazeLayout = [
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 2, 0, 0, 0, 1],
    [1, 0, 1, 1, 1, 1, 1, 1, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 1, 0, 1],
    [1, 0, 1, 0, 1, 1, 0, 1, 0, 1],
    [1, 0, 1, 0, 1, 1, 0, 1, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 1, 0, 1],
    [1, 0, 1, 1, 1, 1, 0, 1, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
];

// Populate Maze
mazeLayout.forEach((row, rowIndex) => {
    row.forEach((cell, colIndex) => {
        const div = document.createElement("div");
        if (cell === 1) div.classList.add("wall");
        if (cell === 0) div.classList.add("pellet");
        if (cell === 2) div.classList.add("power-up");
        maze.appendChild(div);
    });
});

// Initialize Pac-Man Position
let position = { x: 1, y: 1 }; // Start in the first black square
const gridSize = 50;

// Center Pac-Man in the grid cell
function updatePacmanPosition() {
    const offset = (gridSize - 5) / 2; // Adjust to center Pac-Man (size 30px)
    pacman.style.left = `${position.x * gridSize + offset}px`;
    pacman.style.top = `${position.y * gridSize + offset}px`;
}
updatePacmanPosition();

// Enemy Logic
const enemies = [{ x: 8, y: 8, element: null }];
enemies.forEach((enemy) => {
    const div = document.createElement("div");
    div.classList.add("enemy");
    maze.appendChild(div);
    enemy.element = div;
    updateEnemyPosition(enemy);
});

// Center Enemy in the grid cell
function updateEnemyPosition(enemy) {
    const offset = (gridSize - 40) / 2; // Adjust to center Enemy
    enemy.element.style.left = `${enemy.x * gridSize + offset}px`;
    enemy.element.style.top = `${enemy.y * gridSize + offset}px`;
}

function checkCollision(enemy) {
    if (enemy.x === position.x && enemy.y === position.y) {
        if (!powerMode) {
            // End the game immediately if not in power mode
            alert("Game Over! Final Score: " + score);
            window.location.reload();
        } else {
            // Reset the enemy if in power mode
            score += 50; // Add points
            scoreDisplay.textContent = score;

            // Reset enemy position
            enemy.x = 8;
            enemy.y = 8;
            updateEnemyPosition(enemy);
        }
    }
}

function moveEnemies() {
    const speed = 2; // Number of steps per move
    enemies.forEach((enemy) => {
        for (let i = 0; i < speed; i++) {
            let dx = position.x - enemy.x; // Horizontal distance to Pac-Man
            let dy = position.y - enemy.y; // Vertical distance to Pac-Man

            let newX = enemy.x;
            let newY = enemy.y;

            // Always move closer to Pac-Man
            if (Math.abs(dx) > Math.abs(dy)) {
                // Move horizontally
                newX += dx > 0 ? 1 : -1;
            } else {
                // Move vertically
                newY += dy > 0 ? 1 : -1;
            }

            // Check if the move is valid
            if (mazeLayout[newY]?.[newX] !== 1) {
                enemy.x = newX;
                enemy.y = newY;
            } else {
                // If blocked, try the other direction
                if (Math.abs(dx) > Math.abs(dy)) {
                    newY += dy > 0 ? 1 : -1; // Move vertically instead
                } else {
                    newX += dx > 0 ? 1 : -1; // Move horizontally instead
                }

                // Ensure the fallback move is valid
                if (mazeLayout[newY]?.[newX] !== 1) {
                    enemy.x = newX;
                    enemy.y = newY;
                }
            }

            updateEnemyPosition(enemy);

            // Check for collision with Pac-Man
            checkCollision(enemy);
        }
    });
}

// Move the enemies at regular intervals
setInterval(() => {
    moveEnemies(); // Call the enemy movement logic continuously
}, 300); // Adjust the interval (in milliseconds) for enemy movement speed

// Handle Key Presses
document.addEventListener("keydown", (e) => {
    const { x, y } = position;
    let newX = x;
    let newY = y;

    if (e.key === "ArrowUp") newY -= 1;
    if (e.key === "ArrowDown") newY += 1;
    if (e.key === "ArrowLeft") newX -= 1;
    if (e.key === "ArrowRight") newX += 1;

    if (mazeLayout[newY]?.[newX] !== 1) {
        position = { x: newX, y: newY };
        updatePacmanPosition();

        const cellIndex = newY * 10 + newX;
        const cellDiv = maze.children[cellIndex];
        if (cellDiv?.classList.contains("pellet")) {
            cellDiv.classList.remove("pellet");
            score += 10;
            scoreDisplay.textContent = score;
        }
        if (cellDiv?.classList.contains("power-up")) {
            cellDiv.classList.remove("power-up");
            powerMode = true;
            clearTimeout(powerTimer);
            powerTimer = setTimeout(() => (powerMode = false), 10000);
        }
    }
});

// Win Condition
const checkWin = setInterval(() => {
    if (!document.querySelector(".pellet") && !document.querySelector(".power-up")) {
        alert("You win! Final Score: " + score);
        clearInterval(checkWin);
    }
}, 100);

const questions = [
  {
    image: '/pizza.png',
    question: 'What is the main topping of a Margherita pizza?',
    answers: ['Pepperoni', 'Mushrooms', 'Mozzarella Cheese', 'Ham'],
    correct: 2
  },
  {
    image: '/sushi.png',
    question: 'Which country is sushi from?',
    answers: ['China', 'Japan', 'Thailand', 'South Korea'],
    correct: 1
  },
  {
    image: '/taco.png',
    question: 'Which cuisine do tacos belong to?',
    answers: ['Italian', 'Mexican', 'Indian', 'French'],
    correct: 1
  },
  {
    image: "/hamburger.png",
    question: "Which country is the hamburger most associated with?",
    answers: ["USA", "Mexico", "Germany", "Canada"],
    correct: 0
  },
  {
    image: "/pasta.png",
    question: "Which country is famous for pasta?",
    answers: ["France", "Italy", "Greece", "Spain"],
    correct: 1
  },
  {
    image: "/paella.png",
    question: "Paella is a traditional dish from which country?",
    answers: ["Italy", "Mexico", "Spain", "Portugal"],
    correct: 2
  },
  {
    image: "/croissant.png",
    question: "Which country is known for croissants?",
    answers: ["Germany", "Italy", "France", "Belgium"],
    correct: 2
  },
  {
    image: "/samosa.png",
    question: "Which country is samosa traditionally from?",
    answers: ["India", "Pakistan", "Turkey", "China"],
    correct: 0
  }
];

let currentQuestion = 0;
let timeLeft = 60;
let score = 0;
let timer;

function startGame() {
  currentQuestion = 0;
  timeLeft = 60;
  score = 0;
  document.getElementById('score-value').textContent = score;
  document.getElementById('result').textContent = '';
  showQuestion();
  startTimer();
}

function startTimer() {
  clearInterval(timer);
  timer = setInterval(() => {
    timeLeft--;
    document.getElementById('time').textContent = timeLeft;
    if (timeLeft <= 0) {
      clearInterval(timer);
      endGame("Game Over! Time's up.");
    }
  }, 1000);
}

function showQuestion() {
  if (currentQuestion >= questions.length) {
    endGame('Congratulations! You finished the quiz.');
    return;
  }
  const question = questions[currentQuestion];
  document.getElementById('question-image').src = question.image;
  document.getElementById('question-text').textContent = question.question;
  const answersContainer = document.getElementById('answers-container');
  answersContainer.innerHTML = '';
  question.answers.forEach((answer, index) => {
    const button = document.createElement('button');
    button.textContent = answer;
    button.onclick = () => checkAnswer(index);
    answersContainer.appendChild(button);
  });
}

function checkAnswer(selected) {
  const correct = questions[currentQuestion].correct;
  if (selected === correct) {
    score += 100;
    document.getElementById('score-value').textContent = score;
    currentQuestion++;
    showQuestion();
  } else {
    endGame('Game Over! Wrong Answer.');
  }
}

function endGame(message) {
  clearInterval(timer);
  document.getElementById('result').textContent = message;
  document.getElementById('result').className = 'red-text';
  document.getElementById('answers-container').innerHTML = '';
}

document.getElementById('restart-button').onclick = startGame;
document.getElementById('homepage-button').onclick = () => {
  window.location.href = '/index.html';
};

startGame();

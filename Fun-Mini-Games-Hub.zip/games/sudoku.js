let board = document.getElementById('board');
let timerElement = document.getElementById('timer');
let timerInterval;
let seconds = 0;
let puzzle = [];
let originalPuzzle = [];

function startTimer() {
    timerInterval = setInterval(() => {
        seconds++;
        timerElement.textContent = `Time: ${seconds}s`;
    }, 1000);
}

function stopTimer() {
    clearInterval(timerInterval);
}

function generatePuzzle() {
    puzzle = generateSudokuPuzzle();
    originalPuzzle = [...puzzle]; // Store the original unsolved puzzle for comparison
    displayPuzzle(puzzle);
    seconds = 0;
    timerElement.textContent = `Time: 0s`;
    stopTimer();
    startTimer();
}

function displayPuzzle(puzzle) {
    board.innerHTML = '';
    for (let i = 0; i < 81; i++) {
        let input = document.createElement('input');
        input.type = 'text';
        input.maxLength = 1;
        input.dataset.index = i;

        if (puzzle[i] !== 0) {
            input.value = puzzle[i];
            input.disabled = true;
        }

        input.addEventListener('input', handleInput);

        board.appendChild(input);
    }
}

function handleInput(e) {
    const index = e.target.dataset.index;
    const value = parseInt(e.target.value);

    if (isNaN(value) || value < 1 || value > 9) {
        e.target.value = '';
    } else {
        puzzle[index] = value;
    }
}

function solvePuzzle() {
    stopTimer();
    if (solveSudoku([...puzzle])) {
        displayPuzzle(puzzle);
    } else {
        alert("No solution found!");
    }
}

function generateSudokuPuzzle() {
    // Start with a fully solved board
    let board = Array(81).fill(0);
    fillBoard(board);

    // Remove random numbers to create a puzzle with a valid solution
    for (let i = 0; i < 81; i++) {
        if (Math.random() < 0.5) {
            board[i] = 0;
        }
    }

    return board;
}

function fillBoard(board) {
    let grid = Array(81).fill(0);
    solveBoard(grid);  // Solve a completely empty grid to get a valid solution

    // Copy the solved grid into the board
    for (let i = 0; i < 81; i++) {
        board[i] = grid[i];
    }
}

function solveBoard(board) {
    let emptySpot = findEmptySpot(board);
    if (!emptySpot) return true; // Solved

    const [row, col] = emptySpot;
    for (let num = 1; num <= 9; num++) {
        if (isValid(board, row, col, num)) {
            board[row * 9 + col] = num;
            if (solveBoard(board)) return true;
            board[row * 9 + col] = 0; // Reset if not valid
        }
    }
    return false; // Backtrack if no valid number found
}

function findEmptySpot(board) {
    for (let i = 0; i < 81; i++) {
        if (board[i] === 0) {
            return [Math.floor(i / 9), i % 9]; // Return row and column
        }
    }
    return null;
}

function solveSudoku(board) {
    let emptySpot = findEmptySpot(board);
    if (!emptySpot) return true;

    const [row, col] = emptySpot;
    for (let num = 1; num <= 9; num++) {
        if (isValid(board, row, col, num)) {
            board[row * 9 + col] = num;
            if (solveSudoku(board)) {
                puzzle = [...board];  // Update puzzle with solved board
                return true;
            }
            board[row * 9 + col] = 0;
        }
    }
    return false;
}

function isValid(board, row, col, num) {
    // Check row
    for (let i = 0; i < 9; i++) {
        if (board[row * 9 + i] === num) return false;
    }

    // Check column
    for (let i = 0; i < 9; i++) {
        if (board[i * 9 + col] === num) return false;
    }

    // Check 3x3 subgrid
    const boxRowStart = Math.floor(row / 3) * 3;
    const boxColStart = Math.floor(col / 3) * 3;
    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            if (board[(boxRowStart + i) * 9 + boxColStart + j] === num) {
                return false;
            }
        }
    }

    return true;
}

// Initialize the game
generatePuzzle();

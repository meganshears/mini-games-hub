// const canvas = document.getElementById('gameCanvas');
// const ctx = canvas.getContext('2d');

// let bird = {
//     x: 50,
//     y: 150,
//     width: 20,
//     height: 20,
//     gravity: 0.3,  // Constant gravity
//     lift: -7,      // Lift value for flap
//     velocity: 0
// };

// let pipes = [];
// let pipeWidth = 50;
// let pipeGap = 150;
// let pipeSpeed = 2;
// let score = 0;
// let gameOver = false;

// function drawBird() {
//     ctx.fillStyle = "#ffcc00";
//     ctx.fillRect(bird.x, bird.y, bird.width, bird.height);
// }

// function createPipe() {
//     // Ensure the first pipe has an opening
//     const pipeHeight = Math.floor(Math.random() * (canvas.height - pipeGap - 20)) + 20;
//     pipes.push({
//         x: canvas.width,
//         top: pipeHeight,
//         bottom: canvas.height - pipeHeight - pipeGap
//     });
// }

// function drawPipes() {
//     pipes.forEach((pipe, index) => {
//         ctx.fillStyle = "#00ff00";
//         ctx.fillRect(pipe.x, 0, pipeWidth, pipe.top); // Top pipe
//         ctx.fillRect(pipe.x, canvas.height - pipe.bottom, pipeWidth, pipe.bottom); // Bottom pipe
//     });
// }

// function movePipes() {
//     pipes.forEach((pipe, index) => {
//         pipe.x -= pipeSpeed;
//         if (pipe.x + pipeWidth < 0) {
//             pipes.splice(index, 1);
//             score++;
//         }
//     });
// }

// function checkCollisions() {
//     if (bird.y + bird.height >= canvas.height) {
//         gameOver = true;
//     }

//     pipes.forEach(pipe => {
//         if (bird.x + bird.width > pipe.x && bird.x < pipe.x + pipeWidth) {
//             if (bird.y < pipe.top || bird.y + bird.height > canvas.height - pipe.bottom) {
//                 gameOver = true;
//             }
//         }
//     });
// }

// function updateScore() {
//     document.getElementById('score').innerText = score;
// }

// function gameLoop() {
//     if (gameOver) {
//         alert('Game Over! Your score is ' + score);
//         resetGame();
//     }

//     ctx.clearRect(0, 0, canvas.width, canvas.height);
//     drawBird();
//     drawPipes();
//     movePipes();
//     checkCollisions();
//     updateScore();

//     bird.velocity += bird.gravity;
//     bird.y += bird.velocity;

//     requestAnimationFrame(gameLoop);
// }

// function resetGame() {
//     bird.y = 150;
//     bird.velocity = 0;  // Reset velocity to initial state
//     pipes = [];
//     score = 0;
//     gameOver = false;
//     createPipe();
//     gameLoop();
// }

// function flap() {
//     if (!gameOver) {
//         bird.velocity = bird.lift;
//     }
// }

// // Set up the game
// createPipe();

// // Start button handler
// document.getElementById('start-btn').addEventListener('click', function() {
//     document.getElementById('start-screen').style.display = 'none';
//     document.getElementById('game-container').style.display = 'block';
//     createPipe();
//     gameLoop();
// });

// // Go to Homepage button handler
// document.getElementById('home-btn').addEventListener('click', function() {
//     window.location.href = '/index.html'; // Redirect to homepage
// });

// // Instructions button handler
// document.getElementById('instructions-btn').addEventListener('click', function() {
//     document.getElementById('start-screen').style.display = 'none';
//     document.getElementById('instructions-screen').style.display = 'block';
// });

// // Back to menu button handler (from instructions screen)
// document.getElementById('back-to-menu-btn').addEventListener('click', function() {
//     document.getElementById('instructions-screen').style.display = 'none';
//     document.getElementById('start-screen').style.display = 'block';
// });

// // Control the bird with a click
// canvas.addEventListener('click', flap);

// // Create a new pipe every 2 seconds
// setInterval(createPipe, 2000);

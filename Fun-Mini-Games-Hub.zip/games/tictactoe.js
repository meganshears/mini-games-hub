// Tic-Tac-Toe Game Script

let currentPlayer = "X"; // Player X starts the game
let gameBoard = ["", "", "", "", "", "", "", "", ""]; // Empty cells
let gameActive = true;

const cells = document.querySelectorAll('.cell');
const turnIndicator = document.getElementById('turnIndicator');
const restartBtn = document.getElementById('restartBtn');

function checkWinner() {
  const winningCombination = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
    [0, 4, 8], [2, 4, 6] // diagonals
  ];

  for (const combination of winningCombination) {
    const [a, b, c] = combination;
    if (gameBoard[a] && gameBoard[a] === gameBoard[b] && gameBoard[a] === gameBoard[c]) {
      turnIndicator.innerText = `Player ${currentPlayer} Wins!`;
      gameActive = false;
      return;
    }
  }

  if (!gameBoard.includes("")) {
    turnIndicator.innerText = "It's a Draw!";
    gameActive = false;
  }
}

function handleCellClick(index) {
  if (!gameActive || gameBoard[index] !== "") return; // Ignore if already filled or game over

  gameBoard[index] = currentPlayer;
  cells[index].innerText = currentPlayer;
  cells[index].classList.add(currentPlayer.toLowerCase());

  checkWinner();

  if (gameActive) {
    currentPlayer = currentPlayer === "X" ? "O" : "X";
    turnIndicator.innerText = `Player ${currentPlayer}'s Turn`;
  }
}

cells.forEach((cell, index) => {
  cell.addEventListener('click', () => handleCellClick(index));
});

restartBtn.addEventListener('click', () => {
  gameBoard = ["", "", "", "", "", "", "", "", ""];
  cells.forEach(cell => cell.innerText = "");
  cells.forEach(cell => cell.classList.remove("x", "o"));
  currentPlayer = "X";
  turnIndicator.innerText = "Player X's Turn";
  gameActive = true;
});

let currentProblem;
let score = 0;
let difficulty = 'easy';
let questionCount = 0; // Add a counter for the number of questions
const maxQuestions = 10; // Set the maximum number of questions

function startGame(selectedDifficulty) {
    difficulty = selectedDifficulty;
    score = 0;
    questionCount = 0; // Reset question counter when starting a new game
    document.getElementById("score").innerText = score;
    document.getElementById("difficulty-selection").classList.add("hidden");
    document.getElementById("game-screen").classList.remove("hidden");
    generateProblem();
}

function generateProblem() {
    if (questionCount >= maxQuestions) {
        endGame(); // End the game if the maximum number of questions is reached
        return;
    }

    const num1 = getRandomNumber();
    const num2 = getRandomNumber();
    const operations = ['+', '-', '*', '/'];
    const operation = operations[Math.floor(Math.random() * operations.length)];

    currentProblem = {
        question: `${num1} ${operation} ${num2}`,
        answer: calculateAnswer(num1, num2, operation),
    };

    document.getElementById("problem").innerText = currentProblem.question;
    questionCount++; // Increment the question counter
}

function getRandomNumber() {
    if (difficulty === 'easy') return Math.floor(Math.random() * 10) + 1;
    if (difficulty === 'medium') return Math.floor(Math.random() * 50) + 1;
    return Math.floor(Math.random() * 100) + 1;
}

function calculateAnswer(num1, num2, operation) {
    switch (operation) {
        case '+': return num1 + num2;
        case '-': return num1 - num2;
        case '*': return num1 * num2;
        case '/': return Math.round(num1 / num2); // Rounded for simplicity
    }
}

function submitAnswer() {
    const userAnswer = parseInt(document.getElementById("answer").value);
    const feedback = document.getElementById("feedback");

    if (userAnswer === currentProblem.answer) {
        score++;
        feedback.innerText = "Correct!";
        feedback.style.color = "green";
    } else {
        feedback.innerText = `Wrong! The correct answer was ${currentProblem.answer}`;
        feedback.style.color = "red";
    }

    document.getElementById("score").innerText = score;
    document.getElementById("answer").value = '';
    generateProblem();
}

function endGame() {
    document.getElementById("game-screen").classList.add("hidden");
    document.getElementById("end-screen").classList.remove("hidden");
    document.getElementById("final-score").innerText = score;
}

function restartGame() {
    document.getElementById("game-screen").classList.add("hidden");
    document.getElementById("end-screen").classList.add("hidden");
    document.getElementById("difficulty-selection").classList.remove("hidden");
}

function goToHomePage() {
    window.location.href = '/index.html'; // Redirect to index.html
}

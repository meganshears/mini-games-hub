let score = 0;
let currentQuestionIndex = 0;
let questions = [
    {
        question: "Social media is one of the most common ways people communicate today.",
        answer: true
    },
    {
        question: "TikTok was launched before Instagram.",
        answer: false
    },
    {
        question: "The legal voting age in most countries is 18.",
        answer: true
    },
    {
        question: "Video games are only for children.",
        answer: false
    },
    {
        question: "The most popular gaming console in 2024 is the PlayStation 5.",
        answer: true
    },
    {
        question: "The iPhone was released before Android smartphones.",
        answer: true
    },
    {
        question: "You need a degree to start your own business.",
        answer: false
    },
    {
        question: "Netflix was originally a DVD rental service before becoming a streaming platform.",
        answer: true
    },
    {
        question: "Streaming music services like Spotify and Apple Music have replaced physical CDs for most young adults.",
        answer: true
    },
    {
        question: "The world’s first smartphone was released in 2000.",
        answer: false
    }
];

function startGame() {
    score = 0;
    currentQuestionIndex = 0;
    document.getElementById("score").innerText = score;
    document.getElementById("next-button").classList.add("hidden");
    loadQuestion();
}

function loadQuestion() {
    if (currentQuestionIndex < questions.length) {
        const questionObj = questions[currentQuestionIndex];
        document.getElementById("question").innerText = questionObj.question;
        document.getElementById("question-number").innerText = currentQuestionIndex + 1;
        document.getElementById("feedback").innerText = '';
    } else {
        endGame();
    }
}

function checkAnswer(userAnswer) {
    const correctAnswer = questions[currentQuestionIndex].answer;
    const feedbackElement = document.getElementById("feedback");

    if (userAnswer === correctAnswer) {
        score++;
        feedbackElement.innerText = "Correct!";
        feedbackElement.style.color = "green";
    } else {
        feedbackElement.innerText = "Incorrect!";
        feedbackElement.style.color = "red";
    }

    document.getElementById("score").innerText = score;
    currentQuestionIndex++;
    document.getElementById("next-button").classList.remove("hidden");
    document.getElementById("answer-buttons").classList.add("hidden");
}

function nextQuestion() {
    document.getElementById("answer-buttons").classList.remove("hidden");
    document.getElementById("next-button").classList.add("hidden");
    loadQuestion();
}

function endGame() {
    document.getElementById("question-container").innerHTML = `<p>Game Over! Your final score is: ${score}</p>`;
    document.getElementById("answer-buttons").classList.add("hidden");
    document.getElementById("next-button").classList.add("hidden");
}

function goToHomePage() {
    window.location.href = "/index.html"; // Change to the appropriate path for your homepage
}

startGame();
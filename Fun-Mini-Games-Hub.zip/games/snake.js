const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

// Game settings
const boxSize = 20;
const canvasSize = canvas.width;
let score = 0;

// Snake settings
let snake = [{ x: 10, y: 10 }];
let direction = "RIGHT";

// Food settings
let food = generateFood();

// Key controls
document.addEventListener("keydown", changeDirection);

function changeDirection(event) {
  const key = event.key;
  if (key === "ArrowUp" && direction !== "DOWN") direction = "UP";
  else if (key === "ArrowDown" && direction !== "UP") direction = "DOWN";
  else if (key === "ArrowLeft" && direction !== "RIGHT") direction = "LEFT";
  else if (key === "ArrowRight" && direction !== "LEFT") direction = "RIGHT";
}

function generateFood() {
  let newFood;
  do {
    newFood = {
      x: Math.floor(Math.random() * (canvasSize / boxSize)) * boxSize,
      y: Math.floor(Math.random() * (canvasSize / boxSize)) * boxSize,
    };
  } while (snake.some(segment => segment.x === newFood.x && segment.y === newFood.y));
  return newFood;
}

// Main game loop
let gameInterval;
let isPaused = false;
function gameLoop() {
  if (isPaused) return;

  // Move snake
  const head = { ...snake[0] };

  if (direction === "UP") head.y -= boxSize;
  if (direction === "DOWN") head.y += boxSize;
  if (direction === "LEFT") head.x -= boxSize;
  if (direction === "RIGHT") head.x += boxSize;

  // Check collision with food
  if (Math.abs(head.x - food.x) < boxSize && Math.abs(head.y - food.y) < boxSize) {
    score++;
    document.getElementById("score").innerText = `Score: ${score}`;
    food = generateFood();
  } else {
    snake.pop();
  }

  // Check collision with walls or itself
  if (
    head.x < 0 || head.y < 0 || 
    head.x >= canvasSize || head.y >= canvasSize || 
    snake.some(segment => segment.x === head.x && segment.y === head.y)
  ) {
    alert(`Game Over! Your score is ${score}`);
    document.location.reload();
    return;
  }

  snake.unshift(head);
  draw();
}

// Draw snake and food
function draw() {
  ctx.clearRect(0, 0, canvasSize, canvasSize);

  // Draw food
  ctx.fillStyle = "red";
  ctx.fillRect(food.x, food.y, boxSize, boxSize);

  // Draw snake
  ctx.fillStyle = "green";
  snake.forEach(segment => {
    ctx.fillRect(segment.x, segment.y, boxSize, boxSize);
  });
}

// Start and Pause Game
document.getElementById("startButton").addEventListener("click", () => {
  gameInterval = setInterval(gameLoop, 100);
  document.getElementById("startButton").disabled = true;
});

document.getElementById("pauseButton").addEventListener("click", () => {
  isPaused = !isPaused;
  document.getElementById("pauseButton").textContent = isPaused ? "Resume" : "Pause";
});

// Pause game when 'P' is pressed
document.addEventListener("keydown", (event) => {
  if (event.key === "p" || event.key === "P") {
    isPaused = !isPaused;
    document.getElementById("pauseButton").textContent = isPaused ? "Resume" : "Pause";
  }
});

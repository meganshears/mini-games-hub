const mazeWidth = 10;
const mazeHeight = 10;
let maze = [];
let playerPosition = { x: 0, y: 0 };
let endPosition = { x: 9, y: 9 };
let gameOver = false;

// Elements
const mazeContainer = document.getElementById('maze');
const status = document.getElementById('status');
const restartButton = document.getElementById('restart');
const homeButton = document.getElementById('home');

// Generate a simple maze
function generateMaze() {
    maze = [];
    for (let y = 0; y < mazeHeight; y++) {
        maze[y] = [];
        for (let x = 0; x < mazeWidth; x++) {
            if (Math.random() > 0.2) {
                maze[y][x] = 'path';
            } else {
                maze[y][x] = 'wall';
            }
        }
    }
    // Ensure start and end points
    maze[0][0] = 'start';
    maze[mazeHeight - 1][mazeWidth - 1] = 'end';
    renderMaze();
}

// Render the maze
function renderMaze() {
    mazeContainer.innerHTML = '';
    for (let y = 0; y < mazeHeight; y++) {
        for (let x = 0; x < mazeWidth; x++) {
            const cell = document.createElement('div');
            cell.classList.add(maze[y][x]);
            mazeContainer.appendChild(cell);
        }
    }
    movePlayer();
}

// Move the player
function movePlayer() {
    const playerElement = document.createElement('div');
    playerElement.classList.add('player');
    mazeContainer.appendChild(playerElement);
    playerElement.style.top = playerPosition.y * 42 + 'px';
    playerElement.style.left = playerPosition.x * 42 + 'px';
}

// Restart the maze game
restartButton.addEventListener('click', () => {
    gameOver = false;
    playerPosition = { x: 0, y: 0 }; // Reset the player position to the start
    generateMaze();  // Regenerate the maze
    status.textContent = 'Move the yellow square to the red square!';
});

// Go back to homepage (index.html)
homeButton.addEventListener('click', () => {
    window.location.href = '/index.html';  // Redirect to the homepage
});

// Handle player movement with arrow keys
document.addEventListener('keydown', (e) => {
    if (gameOver) return; // Prevent any movement if the game is over

    if (e.key === 'ArrowUp' && playerPosition.y > 0 && maze[playerPosition.y - 1][playerPosition.x] !== 'wall') {
        playerPosition.y--;
    }
    if (e.key === 'ArrowDown' && playerPosition.y < mazeHeight - 1 && maze[playerPosition.y + 1][playerPosition.x] !== 'wall') {
        playerPosition.y++;
    }
    if (e.key === 'ArrowLeft' && playerPosition.x > 0 && maze[playerPosition.y][playerPosition.x - 1] !== 'wall') {
        playerPosition.x--;
    }
    if (e.key === 'ArrowRight' && playerPosition.x < mazeWidth - 1 && maze[playerPosition.y][playerPosition.x + 1] !== 'wall') {
        playerPosition.x++;
    }
    renderMaze();  // Update the maze

    // Check if player reached the end
    if (playerPosition.x === endPosition.x && playerPosition.y === endPosition.y) {
        gameOver = true;  // Set gameOver flag to true
        status.textContent = 'You won! Congratulations!';
    } else {
        status.textContent = 'Keep going!';
    }
});

// Start the game
generateMaze();

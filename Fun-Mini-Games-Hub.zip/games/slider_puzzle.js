const imageUrl = 'puzzle.png'; // Path to your image
let pieces = [];
let emptySlot = 8; // Empty slot is the last one in a 3x3 grid

// Function to render the puzzle
function renderPuzzle() {
    const puzzleContainer = document.getElementById("puzzle-container");
    puzzleContainer.innerHTML = ""; // Clear previous puzzle

    pieces.forEach((piece, index) => {
        const div = document.createElement("div");
        div.classList.add("puzzle-piece");
        div.style.backgroundImage = `url(${imageUrl})`;
        div.style.backgroundPosition = `${piece.x * -100}px ${piece.y * -100}px`;
        div.setAttribute("data-index", index);
        div.addEventListener("click", () => movePiece(index));

        puzzleContainer.appendChild(div);
    });
}

// Function to shuffle the puzzle pieces
function shufflePuzzle() {
    pieces = [];
    let indexes = [];

    // Create the puzzle pieces (3x3 grid)
    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            indexes.push({ x: j, y: i });
        }
    }

    // Shuffle the pieces array
    indexes = indexes.sort(() => Math.random() - 0.5);
    pieces = indexes;

    // Set the empty slot
    emptySlot = 8;

    renderPuzzle();
}

// Function to move a piece into the empty slot
function movePiece(index) {
    const piece = pieces[index];
    const emptyPiece = pieces[emptySlot];

    // Check if the clicked piece is adjacent to the empty slot
    const adjacentIndexes = [
        emptySlot - 3, // Up
        emptySlot + 3, // Down
        emptySlot - 1, // Left
        emptySlot + 1, // Right
    ];

    if (adjacentIndexes.includes(index)) {
        // Swap the pieces
        pieces[emptySlot] = piece;
        pieces[index] = emptyPiece;
        emptySlot = index;
        renderPuzzle();
    }
}

// Function to check if the puzzle is solved
function checkIfSolved() {
    let isSolved = true;

    pieces.forEach((piece, index) => {
        if (piece.x !== index % 3 || piece.y !== Math.floor(index / 3)) {
            isSolved = false;
        }
    });

    if (isSolved) {
        alert("Congratulations! You solved the puzzle!");
    } else {
        alert("The puzzle is not solved yet. Keep trying!");
    }
}

// Initial render of the puzzle
shufflePuzzle();

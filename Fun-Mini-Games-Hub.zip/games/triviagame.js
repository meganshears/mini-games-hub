const categories = {
    general: [
        { question: "What social media platform has the most users globally?", answers: ["Instagram", "TikTok", "Facebook", "Twitter"], correct: 2 },
        { question: "What’s the name of the wizarding school in Harry Potter?", answers: ["Hogwarts", "Ilvermorny", "Beauxbatons", "Durmstrang"], correct: 0 },
        { question: "Which Netflix series features the Hawkins National Laboratory?", answers: ["The Witcher", "Stranger Things", "Outer Banks", "Ozark"], correct: 1 },
        { question: "What is the capital of Japan?", answers: ["Kyoto", "Tokyo", "Osaka", "Nagoya"], correct: 1 },
        { question: "Which artist painted the Mona Lisa?", answers: ["Vincent van Gogh", "Pablo Picasso", "Leonardo da Vinci", "Claude Monet"], correct: 2 },
    ],
    science: [
        { question: "What gas do plants absorb from the atmosphere?", answers: ["Oxygen", "Carbon Dioxide", "Nitrogen", "Hydrogen"], correct: 1 },
        { question: "What planet is known as the 'Red Planet'?", answers: ["Mars", "Jupiter", "Saturn", "Venus"], correct: 0 },
        { question: "What is the chemical symbol for water?", answers: ["O2", "H2O", "CO2", "NaCl"], correct: 1 },
        { question: "What part of the atom has a positive charge?", answers: ["Proton", "Electron", "Neutron", "Nucleus"], correct: 0 },
        { question: "What is the hardest natural substance on Earth?", answers: ["Gold", "Iron", "Diamond", "Graphite"], correct: 2 },
    ],
    history: [
        { question: "What year did the Titanic sink?", answers: ["1910", "1912", "1914", "1920"], correct: 1 },
        { question: "Who was the youngest U.S. president?", answers: ["Barack Obama", "JFK", "Theodore Roosevelt", "Bill Clinton"], correct: 2 },
        { question: "What ancient civilization built the pyramids?", answers: ["Romans", "Egyptians", "Mayans", "Chinese"], correct: 1 },
        { question: "Who discovered America?", answers: ["Christopher Columbus", "Leif Erikson", "Amerigo Vespucci", "Marco Polo"], correct: 0 },
        { question: "What was the first human-made satellite to orbit Earth?", answers: ["Apollo 11", "Sputnik", "Voyager", "Challenger"], correct: 1 },
    ],
    sports: [
        { question: "Which NBA player is nicknamed 'King James'?", answers: ["LeBron James", "Michael Jordan", "Kobe Bryant", "Kevin Durant"], correct: 0 },
        { question: "In soccer, what does 'VAR' stand for?", answers: ["Video Assistant Referee", "Virtual Audio Replay", "Verified Action Replay", "Video Alternate Ruling"], correct: 0 },
        { question: "Which country has won the most FIFA World Cups?", answers: ["Brazil", "Germany", "Italy", "Argentina"], correct: 0 },
        { question: "What is the term for a score of one under par in golf?", answers: ["Birdie", "Eagle", "Bogey", "Par"], correct: 0 },
        { question: "Which sport is known as the 'king of sports'?", answers: ["Basketball", "Baseball", "Soccer", "Tennis"], correct: 2 },
    ]
};

let currentCategory = null;
let currentQuestionIndex = 0;
let score = 0;

function selectCategory(category) {
  currentCategory = categories[category];
  currentQuestionIndex = 0;
  score = 0;
  document.getElementById("category-selection").classList.add("hidden");
  document.getElementById("quiz").classList.remove("hidden");
  showQuestion();
}

function showQuestion() {
  const questionData = currentCategory[currentQuestionIndex];
  document.getElementById("question").textContent = questionData.question;
  const options = document.getElementById("options");
  options.innerHTML = "";

  questionData.answers.forEach((answer, index) => {
      const button = document.createElement("button");
      button.textContent = answer;
      button.onclick = () => checkAnswer(index);
      options.appendChild(button);
  });

  document.getElementById("next-btn").classList.add("hidden");
}

function checkAnswer(selectedIndex) {
  const questionData = currentCategory[currentQuestionIndex];
  if (selectedIndex === questionData.correct) {
      score++;
      alert("Correct!");
  } else {
      alert("Wrong answer!");
  }

  document.getElementById("next-btn").classList.remove("hidden");
}

function nextQuestion() {
  currentQuestionIndex++;
  if (currentQuestionIndex < currentCategory.length) {
      showQuestion();
  } else {
      endGame();
  }
}

function endGame() {
  document.getElementById("quiz").classList.add("hidden");
  document.getElementById("end-screen").classList.remove("hidden");
  document.getElementById("end-message").textContent = `You scored ${score} out of ${currentCategory.length}!`;
}

function restartGame() {
  document.getElementById("end-screen").classList.add("hidden");
  document.getElementById("category-selection").classList.remove("hidden");
}

function goHome() {
  window.location.href = "/"; // Adjust this to your homepage URL
}

document.getElementById("next-btn").addEventListener("click", nextQuestion);

// Define questions and answers
const questions = [
    {
        question: "What is the capital of France?",
        choices: ["Berlin", "Madrid", "Paris", "Rome"],
        answer: 2
    },
    {
        question: "Which continent is Brazil in?",
        choices: ["Africa", "Asia", "South America", "Europe"],
        answer: 2
    },
    {
        question: "Which country is known as the Land of the Rising Sun?",
        choices: ["China", "South Korea", "Japan", "Thailand"],
        answer: 2
    },
    {
        question: "What is the longest river in the world?",
        choices: ["Amazon River", "Nile River", "Yangtze River", "Mississippi River"],
        answer: 1
    }
];

let currentQuestionIndex = 0;
let score = 0;

// Load the first question
function loadQuestion() {
    const questionObj = questions[currentQuestionIndex];
    document.getElementById("question").innerText = questionObj.question;
    const choiceButtons = document.querySelectorAll(".choice");
    choiceButtons.forEach((button, index) => {
        button.innerText = questionObj.choices[index];
    });
}

// Check the answer
function checkAnswer(choiceIndex) {
    const correctAnswerIndex = questions[currentQuestionIndex].answer;
    if (choiceIndex === correctAnswerIndex) {
        score++;
    }

    currentQuestionIndex++;

    if (currentQuestionIndex < questions.length) {
        loadQuestion();
    } else {
        // Game over logic
        document.getElementById("question-container").innerHTML = "<h2>Game Over!</h2>";
        document.getElementById("choices").style.display = "none"; // Hide choices after game over
        document.getElementById("score-container").innerHTML = `<p>Your final score is: ${score}</p>`;
        document.getElementById("home-button").style.display = "block"; // Show homepage button
    }

    document.getElementById("score").innerText = score;
}

// Go to homepage
function goToHomePage() {
    window.location.href = "/index.html";
}

// Initialize the game
loadQuestion();
